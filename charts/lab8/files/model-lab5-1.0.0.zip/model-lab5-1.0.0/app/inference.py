import json, sys, os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "model", "model.pkl")

def load_model(path: str):
    # Заглушка для бинарного артефакта; при реальном использовании заменить на pickle.load
    return {"version": "1.0.0", "path": path}

def predict(texts, model):
    # Пример детерминированного вывода
    results = []
    for t in texts:
        lab = "positive" if any(w in t.lower() for w in ["good","great","love","awesome","прекрасно","отлично"]) else "neutral"
        results.append({"text": t, "sentiment": lab, "confidence": 0.95})
    return results

if __name__ == "__main__":
    data = sys.stdin.read().strip() or "[]"
    texts = json.loads(data)
    model = load_model(MODEL_PATH)
    out = predict(texts, model)
    print(json.dumps(out, ensure_ascii=False))
